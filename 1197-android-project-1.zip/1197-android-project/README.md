# 1197 — Android Studio project

This project wraps the current 1197 prototype in a simple Android WebView app.

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder (`1197-android-project`) in Android Studio.
3. Let Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK path (usually `app/build/outputs/apk/debug/app-debug.apk`).
6. Transfer that APK to your Android phone, open it, and allow installation from that source if Android asks.

## Important limitations
- This is an Android app wrapper around the current local prototype, not a live messenger.
- Profiles and messages are local to the device/browser storage. It cannot deliver messages to another phone yet.
- QR camera scanning may depend on the Android WebView/browser support available on the phone.
- No analytics or remote API calls have been added by this wrapper. The prototype itself is bundled inside the app.
- For real person-to-person messaging, a backend, account/authentication, message delivery, and security design are still required.

## Windows later
The HTML interface can be reused as the starting point for a Windows app. A real Windows package can be built later using a desktop wrapper such as WebView2/Electron/Tauri.
